/**
 * Contém todas as informações e dados dos nós que serão utilizados 
 * pelas listas
 * 
 * @author Lucas Kenji Hayashi, Giovana Akemi Maeda, Pedro Marques Prado, João Pedro Ribeiro
 * @version V2.0 - 17/06/2023
 */
public class No{
    /**
     * Atributos
     */
    //Variáveis de escopo global
    Object conteudo; // conteudo
    No proximo;  // proximo
    No anterior; // anterior
    long id;      //Identificação do nó
    int linha;    //Linhas do mapa de vivos e mortos
    int coluna;   //Colunas do mapa de vivos e mortos

    /**
     * Construtor da classe Nó. Inicializa os objetos, métodos e funções
     * que serão utilizados
     */
    public No(Object conteudo){
        setConteudo(conteudo); //Define o conteúdo de um nó
        setProximo(null); //Define qual será o próximo nó
        setAnterior(null); //Define qual será o nó anterior
        setId(0); //Define a identificação daquele nó
    }
    /**
     * No Construtor
     *
     * @param conteudo dados do No
     * @param id identificação do nó
     * @param linha linhas da matriz gráfica de representação
     * @param coluna colunas da matriz gráfica de representação
     */
    public No(Object conteudo, long id,int linha,int coluna){
        setConteudo(conteudo);
        setProximo(null);
        setAnterior(null);
        setId(id);
        setLinCol(linha,coluna);
    }
    /**
     * setters e getters
     */
    
    /**
     * Método setConteudo
     * Define qual será o conteúdo de um nó
     *
     * @param conteudo Um parâmetro do tipo objeto que contém o 
     * conteúdo daquele nó
     */
    public void setConteudo(Object conteudo){
        this.conteudo = conteudo;
    }
    
    /**
     * Método setProximo
     * Define qual será o próximo nó
     *
     * @param proximo Um parâmetro do tipo No que contém o endereço 
     * do proximo nó na estrutura
     */
    public void setProximo(No proximo){
        this.proximo = proximo;
    }
    
    /**
     * Método setAnterior
     * Define qual será o nó anterior
     *
     * @param anterior Um parâmetro do tipo No que contém o endereço 
     * do nó anterior
     */
    public void setAnterior(No anterior){
        this.anterior = anterior;
    }
    
    /**
     * Método getConteudo
     * Pega o conteúdo que um nó
     *
     * @return O valor de retorno será um objeto com este conteúdo da célula
     */
    public Object getConteudo(){
        return(this.conteudo);
    }
    
    /**
     * Método getProximo
     * Pega o endereço de qual será o próximo nó
     *
     * @return O valor de retorno será o endereço deste próximo nó
     */
    public No getProximo(){
        return(this.proximo);
    }
    
    /**
     * Método getAnterior
     * Pega o endereço de qual será o nó anterior
     *
     * @return O valor de retorno será o endereço deste nó anterior
     */
    public No getAnterior(){
        return(this.anterior);
    }
    
    /**
     * Método setId
     * Define a identificação daquele nó
     *
     * @param id Um parâmetro do tipo long que conterá o número de 
     * identificação
     */
    public void setId(long id){
        this.id = id;
    }
    
    /**
     * Método getId
     * Pega a identificação daquele nó
     *
     * @return O valor de retorno será a identificação daquele nó
     */
    public long getId(){
        return (this.id);
    }
    
    /**
     * Método setLinCol
     * Define quantas linhas e colunas aquela matriz gráfica 
     * terá a representando
     *
     * @param linha Um parâmetro do tipo int com a quantidade de 
     * linhas desta matriz de representação gráfica
     * 
     * @param coluna Um parâmetro do tipo int com a quantidade de 
     * colunas desta matriz de representação gráfica
     */
    public void setLinCol(int linha,int coluna){
        this.linha = linha;
        this.coluna = coluna;
    }
    
    /**
     * Método getLin
     * Pega a quantidade de linhas definidas pelo usuário
     *
     * @return O valor de retorno será do tipo int e contém a 
     * quantidade de linhas definida pelo usuário
     */
    public int getLin(){
        return this.linha;
    }
    /**
     * Método getCol
     * Pega a quantidade de colunas definidas pelo usuário
     *
     * @return O valor de retorno será do tipo int e contém a 
     * quantidade de colunas definida pelo usuário
     */
    public int getCol(){
        return this.coluna;
    }
    
    /**
     * Método toString
     * Transforma o objeto que contém as informações que aquele nó
     * carrega e os transforma em uma String
     *
     * @return O valor de retorno será do tipo String e conterá 
     * todos os dados que foram transformados agora em formato de String
     */
    public String toString(){
        //return "ID: " + getId() + " " + getConteudo().toString(); 
        return(conteudo.toString());
    }
}
