import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
/**
 * Aqui estão todos os efeitos gráficos, user-interfaces (UI) e detalhes
 * também visuais relacionados ao círculo e demais menus que são
 * renderizados ao usuário
 * 
 * @author Lucas Kenji Hayashi, Giovana Akemi Maeda, Pedro Marques Prado, João Pedro Ribeiro
 * @version V2.0 - 17/06/2023
 */
public class CirculoGraf extends Circulo implements MouseListener, ActionListener, MouseMotionListener
{
    //Variáveis de escopo global
    Simulacao _simular;
    JFrame _jframe = null; //janela principal
    Container _pAmbiente = null; //container do ambiente (Soldados)
    JLabel [][]_labels = null; //matriz de labels

    JTextField _tnindividuos = null;
    JTextField _tintervalo = null;
    JTextField _ttempoespera = null;

    Color _corCelulas = null; 
    Color _corFundo = null;
    Color _corBorda = null;
    Color _corVazio = null;

    Container _pBotoes = null;  //container dos botoes
    JButton _executar = null;   //Botao para executar o problema de Josephus
    JButton _configurar = null; //Botao para configurar, declarar o numero de soldados, intervalo entre as mortes e delay entre elas
    JButton _reiniciar = null;  //Botao para reiniciar todo processo
    JButton _sair = null;       //Botao para sair

    JMenuBar _menuBar;
    JMenu _menuNindividuos;
    JMenu _menuIntervalo;
    JMenu _menuTempo;
    JMenu _menuAjuda;
    JMenuItem _menuAjudaSobre;

    /**
     * Método getCorBorda
     * Pega qual a cor atual da borda do quadradinho/soldado
     *
     * @return O valor de retorno será a cor da borda do quadradinho/soldado
     */
    public Color getCorBorda(){
        return _corBorda;
    }

    /**
     * Método setCorBorda
     * Define uma nova cor de borda para o quadradinho/soldado
     *
     * @param borda Um parâmetro do tipo Cor que define a nova
     * cor da borda do quadradinho/soldado
     */
    public void setCorBorda(Color borda){
        this._corBorda = borda;
    } 

    /**
     * Método getCorCelulas
     * Pega qual a cor atual do quadradinho/soldado
     *
     * @return O valor de retorno será a cor do quadradinho/soldado
     */
    public Color getCorCelulas() {
        return _corCelulas;
    } 

    /**
     * Método setCorCelulas
     * Define uma nova cor para o quadradinho/soldado
     *
     * @param borda Um parâmetro do tipo Cor que define a nova
     * cor do quadradinho/soldado
     */
    public void setCorCelulas(Color celulas) {
        _corCelulas = celulas;
    }

    /**
     * Método getCorFundo
     * Pega qual será a cor do background
     *
     * @return O valor de retorno será a cor do background
     */
    public Color getCorFundo() {
        return _corFundo;
    }

    /**
     * Método setCorFundo
     * Permite a alteração de qual será a cor do background
     *
     * @param fundo Um parâmetro
     */
    public void setCorFundo(Color fundo) {
        _corFundo = fundo;
    } 
    
    /**
     * Método setCorVazio
     * Define uma cor para os quadradinhos que estão vazio
     * ou nao sendo utilizado
     *
     * @param fundo Um parâmetro
     */
    public void setCorVazio(Color vazio){
        _corVazio = vazio;
    }

    /**
     * Método getCorVazio
     * Pega a cor dos quadradinhos vazios/nao utilizados
     *
     * @return O valor de retorno será a cor dos quadradinhos que
     * estao vazios
     */
    public Color getCorVazio(){
        return _corVazio;
    }
    
    // CRIA o menu principal, recebendo qnt de linhas e colunas
    /**
     * CirculoGraf Construtor
     * CRIA o menu principal, recebendo qnt de linhas e colunas
     *
     * @param linhas Um parâmetro do tipo int que conterá a quantidade
     * de linhas desta rodada
     * 
     * @param colunas Um parâmetro do tipo int que conterá a quantidade
     * de colunas desta rodada
     */
    CirculoGraf(int linhas, int colunas) {
        super(linhas,colunas);

        _jframe = new JFrame("Problema de Josephus");
        _jframe.setSize(500,500);
        _jframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        _jframe.setLocationRelativeTo(null);

        //painel de ambiente 
        _pAmbiente = new JPanel();
        _pAmbiente.setLayout(new GridLayout(linhas, colunas));
        _labels = new JLabel [linhas][colunas];
        setCorCelulas(Color.RED);
        setCorFundo(Color.CYAN);
        setCorBorda(Color.WHITE );
        setCorVazio(Color.BLACK);

        _pBotoes = new JPanel();

        _pBotoes.setLayout(new FlowLayout());

        _menuBar = new JMenuBar();
    }

    /**
     * Método adicionaComponentes
     * Adiciona todos os componentes visuais principais a janela
     */
    public void adicionaComponentes(){
        Container pane = _jframe.getContentPane();

        inserePainelAmbiente(pane);

        inserePainelBotoes(pane);

        insereMenu();
    }

    //CRIA o menu configurar
    // INICIALIZADORES dos Labels, Txfs, Btns
    JLabel lblNumIndividuos, lblIntervalo, lblDelay;
    JTextField txfNumIndividuos, txfIntervalo, txfDelay;
    JButton btnConfigConfirmar, btnConfigCancelar;
    JFrame fConfig;
    
    /**
     * Método menuConfigurar
     * Cria o menu de configurações e definições principais para o
     * funcionamento principal do programa, permitindo assim que o
     * usuário defina seus valores desejados
     *
     */
    void menuConfigurar(){
        // CRIA o frame e o panel
        fConfig = new JFrame("CONFIGURACOES");
        fConfig.setSize(400, 200);
        JPanel pConfig = new JPanel();
        pConfig.setLayout(new GridLayout(4, 2, 10, 10));

        // CRIA os labels, txfs, btns
        lblNumIndividuos = new JLabel("Numero de individuos: ");
        lblIntervalo = new JLabel("Intervalo entre mortes: ");
        lblDelay = new JLabel("Delay de tempo (em miliseg): ");
        txfNumIndividuos = new JTextField(10);
        txfIntervalo = new JTextField(10);
        txfDelay = new JTextField(10);
        btnConfigConfirmar = new JButton("Confirmar");
        btnConfigCancelar = new JButton("Cancelar");

        // FAZ os btns clicaveis
        btnConfigConfirmar.addActionListener(this);
        btnConfigCancelar.addActionListener(this);

        // INSERE os labels, txfs, btns no PANEL
        pConfig.add(lblNumIndividuos);
        pConfig.add(txfNumIndividuos);
        pConfig.add(lblIntervalo);
        pConfig.add(txfIntervalo);
        pConfig.add(lblDelay);
        pConfig.add(txfDelay);
        pConfig.add(btnConfigCancelar);
        pConfig.add(btnConfigConfirmar);

        // INSERE o PANEL no FRAME
        fConfig.add(pConfig);

        //fConfig.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        fConfig.setDefaultCloseOperation(fConfig.DISPOSE_ON_CLOSE);
        fConfig.setVisible(true);
        fConfig.setResizable(false);
        fConfig.setLocationRelativeTo(null);

    }

    /**
     * Método mousePressed
     * Quando o mouse pressionar um componente em específico
     *
     * @param e Um parâmetro de captura de ação
     */
    public void mousePressed(MouseEvent e){
        Component c = e.getComponent();

        if(c instanceof JButton){
            JButton jb = (JButton)c;

            if(jb.getText().equals("Executar")){
                //processo de execucao
                iniciarAnimacao();

                finalizarAnimacao();
                reiniciar();
                desenhaCirculo();
                iniciarAnimacao();
            }
            else if(jb.getText().equals("Reiniciar")){
                //reiniciar o processo, se estiver rodando
                finalizarAnimacao();
                reiniciar();
                desenhaCirculo();
            }
            else if(jb.getText().equals("Configurar")){
                //abre o JMenu, permite as alteracoes de informacao
                menuConfigurar();

            }
            else if(jb.getText().equals("Sair")){
                System.exit(0);
            }

        }
    }

    public void mouseReleased(MouseEvent e) {
    }

    public void mouseEntered(MouseEvent e) {
    }

    public void mouseExited(MouseEvent e) {
    }

    public void mouseClicked(MouseEvent e) {
    }

    public void mouseDragged(MouseEvent e) {
    }

    public void mouseMoved(MouseEvent e) {
    }

    /**
     * Método actionPerformed
     * Caso alguma ação seja realizada pelo usuário, aqui
     * estarão todas as suas possibilidades de resposta e ação
     *
     * @param e Um parâmetro de captura de ação
     */
    public void actionPerformed(ActionEvent e){
        String c = e.getActionCommand();

        if(c.equals("Sair")){
            System.exit(0);
        }
        else if(c.equals("Sobre")){
            sobre();
        }

        // MENU CONFIG
        if (e.getSource() == btnConfigCancelar){
            fConfig.dispose();
        }
        else if(e.getSource() == btnConfigConfirmar){
            // PEGA os valores dos labels
            String numIndividuos = txfNumIndividuos.getText();
            String intervalo = txfIntervalo.getText();
            String delay = txfDelay.getText();

            // TENTA converter as strings em INT
            try{
                int ninovo = Integer.parseInt(numIndividuos);
                int intervalonovo = Integer.parseInt(intervalo);
                int delaynovo = Integer.parseInt(delay);

                if (ninovo > 1600 || ninovo < 2){
                    JOptionPane.showMessageDialog(null,
                        "Insira entre 2 e 1600 individuos");
                }else{
                    setDelay(delaynovo);
                    setIntervalo(intervalonovo);
                    setNI(ninovo);
                    // PASSA as infos e fecha o menu caso de td certo
                    fConfig.dispose();
                }

            }
            // SENAO abre um popup com o erro
            catch(NumberFormatException ee){
                JOptionPane.showMessageDialog(null,
                    "Insira numeros nos campos apenas");
            }

        }
    }

    /**
     * Método desenhaCirculo
     * Mostra ao usuário este circulo/matriz que foi criado
     * de acordo com as suas escolhas de preferências
     *
     */
    public void desenhaCirculo(){
        int k = 0;
        for(int i = 0;i < getCirculo().length;i++){
            for(int j = 0;j < getCirculo()[i].length;j++){
                if(k < nindividuos){
                    
                    if (getCirculo()[i][j].getSoldado() == false) {
                        _labels[i][j].setBackground(getCorCelulas());
                        _labels[i][j].setForeground(getCorCelulas());
                    }
                    else if(getCirculo()[i][j].getSoldado() == true){
                        _labels[i][j].setBackground(getCorFundo());
                        _labels[i][j].setForeground(getCorFundo());
                    }
                    
                }
                else{                   
                    _labels[i][j].setBackground(getCorVazio());
                    _labels[i][j].setForeground(getCorVazio());
                }
                k++;
            }
        }
    }

    public class Simulacao extends Thread {
        public boolean continuar = true;

        /**
         * Método run
         * Executa estas ações que fazem o funcionamento inicial
         *
         */
        public void run(){
            try{
                lista = arm.getInicio();
                while(continuar){
                    //processo
                    Execucao(intervalo);
                    desenhaCirculo();

                    //finalizarAnimacao();
                    //reiniciar();
                    //desenhaCirculo();
                    //iniciarAnimacao();

                    sleep(delay);
                    if(arm.getQtdNos() == 1){
                        continuar = false;
                    }
                }

            } catch (Exception e) {
                System.out.println("ERRO NO THREADING");
                System.out.println(e);
                System.exit(0);
            }
        }    
    }

    /**
     * Método iniciarAnimacao
     * Mostra uma pequena animação ao usuário ao performar
     * alguma ação em específico
     *
     */
    public void iniciarAnimacao(){
        _simular = new Simulacao();
        _simular.start();
        _executar.setEnabled(false);
        _reiniciar.setEnabled(true);
        _configurar.setEnabled(false);
    }
    
    /**
     * Método finalizarAnimacao
     * Finaliza uma animação que foi iniciada posteriormente
     * para entrega de efeitos visuais
     *
     */
    public void finalizarAnimacao() {
        _simular.continuar = false;
        _executar.setEnabled(true);
        _reiniciar.setEnabled(false);
        _configurar.setEnabled(true);
        _simular = null;
    }

    /**
     * Método mostraCirculoGUI
     * Responsável por renderizar todos os pequenos detalhes da
     * janela popup
     *
     */
    public void mostraCirculoGUI() {
        JFrame.setDefaultLookAndFeelDecorated(true);

        adicionaComponentes();

        _jframe.pack();
        _jframe.setVisible(true);
    }

    /**
     * Método inserePainelAmbiente
     * Insere todo o painel com sua folha de estilo correspondente
     * para uma apresentação melhorada de efeitos visuais ao usuário final
     *
     * @param pane Um parâmetro do tipo Container que conterá a
     * divisão pai para o abrigamento de seus componentes filhos
     * (botões, labels, tamanhos, entre outros)
     */
    public void inserePainelAmbiente(Container pane){

        for (int i = 0; i < _labels.length; i++) {
            for (int j = 0; j < _labels[i].length; j++) {

                // Cria o jlabel de define os atributos
                _labels[i][j] =  new JLabel (""+ i +","+ j);
                _labels[i][j].setPreferredSize(new Dimension (15, 15));
                _labels[i][j].setMaximumSize(new Dimension (15, 15));
                _labels[i][j].setMinimumSize(new Dimension (15, 15));
                _labels[i][j].setToolTipText("(" + (39-i) + "," + (39-j) + ")");
                _labels[i][j].setOpaque(true);
                _labels[i][j].setForeground(getCorFundo());
                _labels[i][j].setBorder(BorderFactory.createLineBorder(getCorBorda()));
                _labels[i][j].setBackground(getCorFundo());
                // Adiciona o jlabel para o painel de ambiente
                _pAmbiente.add(_labels[i][j], 0);
            }

        }
        pane.add("North", _pAmbiente);
    }

    /**
     * Método inserePainelBotoes
     * Insere todos os botões visíveis ao menu de escolhas do usuário
     *
     * @param pane Um parâmetro do tipo Container que conterá a
     * divisão pai para o abrigamento de seus componentes filhos
     * (botões, labels, tamanhos, entre outros)
     */
    public void inserePainelBotoes(Container pane){
        _executar = new JButton("Executar");
        _executar.setToolTipText("Inicia o processo de execucao");
        _executar.addMouseListener(this);

        _reiniciar = new JButton("Reiniciar");
        _reiniciar.setToolTipText("Atualiza o processo ao estado inicial");
        _reiniciar.addMouseListener(this);
        _reiniciar.setEnabled(false);

        _configurar = new JButton("Configurar");
        _configurar.setToolTipText("Pressione para permitir atualizacao de info");
        _configurar.addMouseListener(this);

        _sair = new JButton("Sair");
        _sair.setToolTipText("Sair");
        _sair.addMouseListener(this);

        _pBotoes.add(_executar);
        _pBotoes.add(_reiniciar);
        _pBotoes.add(_configurar);
        _pBotoes.add(_sair);

        pane.add("South", _pBotoes);
    }

    /**
     * Método insereMenu
     * Insere um mini menu de opções no topo da janela o qual
     * contém algumas funcionalidades e deatlhes extras não-essenciais
     *
     */
    public void insereMenu(){
        // Ajuda
        _menuAjuda = new JMenu("Ajuda");
        _menuAjuda.setMnemonic(KeyEvent.VK_J);
        _menuBar.add(_menuAjuda);

        // Ajuda item Sobre
        _menuAjudaSobre = new JMenuItem("Sobre", KeyEvent.VK_S);
        _menuAjudaSobre.setAccelerator(KeyStroke.getKeyStroke(
                KeyEvent.VK_S, ActionEvent.ALT_MASK));
        _menuAjudaSobre.getAccessibleContext().setAccessibleDescription(
            "This doesn't really do anything");
        _menuAjudaSobre.addActionListener(this);
        _menuAjuda.add(_menuAjudaSobre);
        _jframe.setJMenuBar(_menuBar);
    }

    /**
     * Método sobre
     * Painel que está contido no pequeno menu do topo da janela o qual
     * demonstra todos os integrantes do grupo
     *
     */
    public void sobre(){
        JFrame frame = new JFrame();
        JOptionPane.showMessageDialog(frame,"Programa de Josephus - LP 2023\n\n Docente: Julio Arakaki\n\n Integrantes:\n Pedro Marques Prado\n Lucas Kenji Hayashi\n Giovana Akemi Maeda\n João Pedro Ribeiro"); 
    }
   
    /**
     * Método vassoura
     * Esse método retorna o ultimo soldado sobrevivente
     * @retorna o valor do ultimo sobrevivente
     */
    public int vassoura(){
        int cont = 0;
        
        for (int i=0; i<getCirculo().length; i++){
            for (int j=0; j<getCirculo()[i].length; j++){
                
            }
            
            
        }
        
        return cont;
    }

}