import javax.swing.JOptionPane;
/**
 * Classe que contém o executável principal do programa, aqui começa tudo
 * 
 * @author Lucas Kenji Hayashi, Giovana Akemi Maeda, Pedro Marques Prado, João Pedro Ribeiro
 * @version V2.0 - 17/06/2023
 */
public class Aplicacao
{
    /**
    * Método main
    * Responsável por fazer a execução básica do projeto
    *
    */
   public static void main(String args[]){
       CirculoGraf run = new CirculoGraf(40,40);
       run.mostraCirculoGUI();
   }
}
