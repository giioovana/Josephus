 /**
 * Interface com todos os métodos básicos da classe
 * ListaDuplamenteLigadaCircular
 * 
 * @author Lucas Kenji Hayashi, Giovana Akemi Maeda, Pedro Marques Prado, João Pedro Ribeiro
 * @version V2.0 - 17/06/2023
 */
public interface IListaDuplamenteLigadaCircular{
    //Verifica se a lista contém nós ou se ela está vazia
    public boolean estaVazia(); 
    //Insere no início os novos nós naquela lista
    public void inserirInicio(Object novo,int linha,int coluna); 
    //Insere um novo nó no fim daquela lista
    public void inserirFim(Object novo,int linha,int coluna);
    //Insere um novo nó no final da lista
    public boolean inserirApos(long chave, Object novo,int linha,int coluna);
    //Remove um nó e todos os seus dados do início daquela lista
    public Object removerInicio();
    //Remove um nó e todos os seus dados do fim daquela lista
    public Object removerFim();
    //Remove um nó que está presente na lista
    public Object remover(long chave);
    //semelhante comportamento ao toString anterior
    public String toStringDoFim();
    //Pega a quantidade de nós que aquela lista contém
    public int getQtdNos();
    //Pega o endereço do nó inicial
    public No getInicio();
}
