import java.util.Random;
/**
 * Esta classe contém todos os detalhes do círculo de Josephus
 * e suas propriedades básicas
 * 
 * @author Lucas Kenji Hayashi, Giovana Akemi Maeda, Pedro Marques Prado, João Pedro Ribeiro
 * @version V2.0 - 17/06/2023
 */
public class Circulo
{
    //Variaveis declaradas com escopo global
    IListaDuplamenteLigadaCircular arm = new ListaDuplamenteLigadaCircular();
    Soldado sol[][]; //Matriz que abrigará todos os soldados e suas informações
    No lista;
    int intervalo = 3; //intervalo entre cada morte
    int nindividuos = 1600; //numero de individuos
    int delay = 300;    //delay para ocorrer as mortes
    
    /**
     * Construtor da classe Circulo. Inicializa os objetos, métodos e funções
     * que serão utilizados
     */
    Circulo(int linhas, int colunas){
        setCirculo(new Soldado[linhas][colunas]);
        iniciarCirculo(nindividuos);
    }

    
    /**
     * Método setNI
     * Define o numero de indivíduos
     * 
     * @param nindividuos Um parâmetro que tem a quantidade de indivíduos
     */
    public void setNI(int nindividuos){
        this.nindividuos = nindividuos;
    }

    /**
     * Método getNI
     * Pega o numero de individuos declarado
     *
     * @return O valor de retorno será do tipo nindividuos e terá
     * a quantidade de indivíduos que foi definido
     */
    public int getNI(){
        return nindividuos;
    }

    /**
     * Método setIntervalo
     * Define o intervalo existente entre cada morte dos soldados
     *
     * @param intervalo Um parâmetro do tipo intervalo que contem o
     * intervalo de passos entre as mortes
     */
    public void setIntervalo(int intervalo){
        this.intervalo = intervalo;
    }

    /**
     * Método getIntervalo
     * Pega o valor do intervalo entre as eliminações dos soldados
     *
     * @return 0 valor de retorno será do tipo intervalo e conterá o
     * valor de declarado para o intervalo entre as mortes
     */
    public int getIntervalo(){
        return intervalo;
    }

    /**
     * Método setDelay
     * Define o tempo de delay entre cada eliminação
     *
     * @param delay Um parâmetro do tipo Delay com o tempo de atraso
     * entre as eliminações
     */

    public void setDelay(int delay){
        this.delay = delay;
    }

    /**
     * Método getDelay
     * Pega o tempo de delay declarado para as eliminações ocorrerem
     *
     * @return O valor de retorno será do tipo delay e conterá o 
     * tempo de atraso entre as mortes dos soldados 
     */
    
    public int getDelay(){
        return delay;
    }

    /**
     * Método Execucao
     * Elimina um dos soldados de acordo com a quantidade de
     * passos que for definida pelo usuário
     *
     * @param passo Um parâmetro do tipo int que conterá a faixa de período
     * de eliminação de cada soldado
     */
    public void Execucao(int passo){
        long id;int i;int j;
        if(arm.getQtdNos() != 1){
            for(int k = 1;k < passo;k++){
                lista = lista.getProximo();
            }
            id = lista.getId();
            i = lista.getLin();
            j = lista.getCol();
            getCirculo()[i][j].setSoldado(false);
            lista = lista.getProximo();
            arm.remover(id);
        }
    }
    
    /**
     * Método iniciarCirculo
     * Cria e inicia uma nova matriz/circulo que conterá todos
     * os soldados de acordo com o número que for definido pelo usuário
     *
     */
    public void iniciarCirculo(int qtdInd){
        int k = 0;
        for(int i = 0;i < getCirculo().length;i++){
            for(int j = 0;j < getCirculo()[i].length;j++){
                if(k < nindividuos){
                    getCirculo()[i][j] = new Soldado();
                    arm.inserirInicio(getCirculo()[i][j],i,j);
                    //System.out.println("k:" + k);
                }
                k++;
            }
        
        }
        System.out.println("nindividuos:" + nindividuos);
    }
    
    //Ambiente do circulo e suas componentizações
    
    /**
     * Método setCirculo
     * Define o círculo da roda para o preparamento das eliminações
     *
     * @param circulo Um parâmetro do tipo Soldado com a matriz 
     * de círculo que abriga todos os soldados
     */
    public void setCirculo(Soldado [][]circulo){
        sol = circulo;
    }

    /**
     * Método getCirculo
     * Pega a matriz do círculo que foi criado
     *
     * @return O valor de retorno será do tipo Soldado e conterá o círculo
     */
    public Soldado [][]getCirculo(){
        return this.sol;
    }

    /**
     * Método devolverValor
     * Pega as informações daquele soldado e mostra o seu status de vida
     *
     * @param linha Um parâmetro do tipo int que contém a linha que
     * está este soldado
     * 
     * @param coluna Um parâmetro do tipo int que contém a coluna que
     * está este soldado
     * 
     * @return O valor de retorno será o soldado que estiver naquela
     * posição em específico
     */
    boolean devolverValor(int linha, int coluna) {
        return (getCirculo()[linha][coluna].getSoldado());
    }

    /**
     * Método copiarMapa
     * O seu objetivo é auto-descritivo, ele copia o mapa atual do
     * círculo de soldados
     *
     * @param novoMapa Um parâmetro do tipo Circulo que conterá 
     * o novo mapa que for criado
     */
    public void copiarMapa(Circulo novoMapa) {
        for(int i=0; i < getCirculo().length; i++){
            for (int j=0; j < getCirculo()[i].length; j++){
                try{
                    getCirculo()[i][j].setSoldado(novoMapa.devolverValor(i, j));   
                }catch(Exception e){
                    if(getCirculo()[i][j] == null){
                        getCirculo()[i][j] = new Soldado();
                        //getCirculo()[i][j] = null;
                    }
                }
            }
        }
    }

    /**
     * Método limparCirculo
     * Limpa o círculo de soldados e todas as suas respectivas
     * informações
     *
     */
    public void limparCirculo() {
        for(int i=0; i < getCirculo().length; i++){
            for (int j=0; j < getCirculo()[i].length; j++){
                getCirculo()[i][j].setSoldado(true);
            }
        }
    }

    /**
     * Método reiniciar
     * Reiniciará o círculo totalmente e todos os soldados
     * irão voltar a vida copiando o mapa anterior com suas
     * respectivas configurações
     *
     */
    public void reiniciar(){
        arm = new ListaDuplamenteLigadaCircular();  
        Circulo novoMapa = new Circulo(getCirculo().length, getCirculo()[0].length);
        copiarMapa(novoMapa);
        iniciarCirculo(nindividuos);
    }
}
