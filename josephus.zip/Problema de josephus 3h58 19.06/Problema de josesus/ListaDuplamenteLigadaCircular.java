import java.util.Random;

/**
 * Contém toda a funcionalidade básica para o funcionamento
 * correto da estrutura de dados baseada em Lista Duplamente Ligada Circular
 * 
 * @author Lucas Kenji Hayashi, Giovana Akemi Maeda, Pedro Marques Prado, João Pedro Ribeiro
 * @version V2.0 - 17/06/2023
 */
public class ListaDuplamenteLigadaCircular implements IListaDuplamenteLigadaCircular {
    private No inicio; //Referência para o primeiro nó de uma lista
    private No fim;    //Referência para o último nó de uma lista
    int qtdNos; //Quantidade de nos que aquela lista possui
    private Random r = new Random(System.currentTimeMillis());//Inicia um novo sistema randômico
    
    // -------------------------------------------------------------
    /**
     * Construtor da classe ListaDuplamenteLigadaCircular. Inicializa os objetos, métodos e funções
     * que serão utilizados
     */
    public ListaDuplamenteLigadaCircular() {   
        setInicio(null);
        setFim(null);
        setQtdNos(0);
    }
    // Setters e Getters
    /**
     * Method getInicio
     * Pega o endereço do nó inicial
     *
     * @return endereco do primeiro nó de uma lista
     */
    public No getInicio() {
        return inicio;
    }
    /**
     * Método setInicio
     * Define qual será o primeiro nó de uma lista
     *
     * @param inicio Um parâmetro do tipo No que conterá o endereço
     * do primeiro nó de uma lista
     */
    public void setInicio(No inicio) {
        this.inicio = inicio;
    }

   /**
     * Method getFim
     * Pega o endereço do útlimo nó de uma lista
     *
     * @return endereco do ultimo nó que aquela lista contém
     */
    public No getFim() {
        return fim;
    }
    /**
     * Método setFim
     * Define qual será o nó final de uma lista
     *
     * @param fim Um parâmetro do tipo No que contém o endereço
     * do último nó de uma lista
     */
    public void setFim(No fim) {
        this.fim = fim;
    }

    /**
     * Metodo getQtdNos
     * Pega a quantidade de nós que aquela lista contém
     *
     * @return do tipo int que conterá a quantidade de nós ativos
     * de uma lista
     */
    public int getQtdNos(){
        return this.qtdNos;
    }

    /**
     * Metodo setQtdNos
     * Define a quantidade de nós que aquela lista irá conter
     *
     * @param qtdNos permite que a quantidade de nós de uma lista
     * seja modificada
     */
    private void setQtdNos(int qtdNos){
        this.qtdNos = qtdNos;
    }

    
    // -------------------------------------------------------------
    /**
     * Método estaVazia
     * Verifica se a lista contém nós ou se ela está vazia
     *
     * @return O valor de retorno será do tipo booleano e fará 
     * a verificação do status desta lista (se contém nós ativos ou não)
     */
    public boolean estaVazia() {
        return getInicio() == null; 
    }

    // -------------------------------------------------------------
    /**
     * Método inserirInicio
     * Insere no início os novos nós naquela lista
     *
     * @param elem Um parâmetro do tipo objeto que contém o 
     * elemento daquele nó
     * 
     * @param linha Um parâmetro do tipo int que contém a 
     * posição de linha que aquele nó irá ficar
     * 
     * @param coluna Um parâmetro do tipo int que contém a
     * posição de coluna que aquele nó irá ficar
     */
    public void inserirInicio(Object elem,int linha,int coluna) {

        No novoNo = new No(elem, r.nextLong(),linha,coluna);   // make new link
        //Verifica se a lista esta vazia e define o endereço do inicio ou do fim
        if( estaVazia() ) { 
            setFim(novoNo);
        } else {
            getInicio().setAnterior(novoNo); // 1
        }
        
        //Define os dados relacionados ao novo nó
        novoNo.setProximo(getInicio()); // 2
        setInicio(novoNo); // 3
        getFim().setProximo(getInicio()); // 4
        getInicio().setAnterior(getFim()); //5
        // Incrementa qtidade de nos
        setQtdNos(getQtdNos() + 1);

    }

    // -------------------------------------------------------------
    /**
     * Método inserirFim
     * Insere um novo nó no fim daquela lista
     *
     * @param elem Um parâmetro do tipo objeto que contém o 
     * elemento daquele nó 
     * 
     * @param linha Um parâmetro do tipo int que contém a 
     * posição de linha que aquele nó irá ficar
     * 
     * @param coluna Um parâmetro do tipo int que contém a
     * posição de coluna que aquele nó irá ficar
     */
    public void inserirFim(Object elem,int linha,int coluna)    {
        No novoNo = new No(elem, r.nextLong(),linha,coluna);  

        if( estaVazia() ) {
            setInicio(novoNo);
        } else {
            getFim().setProximo(novoNo); //1
            novoNo.setAnterior(getFim()); //2
        }
        setFim(novoNo); //3
        getFim().setProximo(getInicio()); // 4
        getInicio().setAnterior(getFim()); //5
        // Incrementa quantidade de nos
        setQtdNos(getQtdNos() + 1);

    }

    // -------------------------------------------------------------
    /**
     * Método removerInicio
     * Remove um nó e todos os seus dados do início daquela lista
     *
     * @return O valor de retorno será do tipo No e retornará 
     * um nó temporário
     */
    public No removerInicio() {
        //Define um novo nó temporário
        No temp = null;
        
        //Verifica se a lista está vazia
        if(getInicio() != null && getFim() != null) {
            temp = getInicio();

            if (getInicio() == getFim()) {
                setInicio(null);
                setFim(null);
            } else {
                getFim().setProximo(getInicio().getProximo());
                getInicio().getProximo().setAnterior(getFim()); 
                setInicio(getInicio().getProximo());
            }
            temp.setAnterior(null);
            temp.setProximo(null);
        }
        // Decrementa qtidade de nos
        setQtdNos(getQtdNos() - 1);
        return temp;
    }

    // -------------------------------------------------------------
    /**
     * Método removerFim
     * Remove um nó e todos os seus dados do fim daquela lista
     *
     * @return O valor de retorno será do tipo No e retornará 
     * um nó temporário
     */
    public No removerFim() {
        //Define um novo nó temporário
        No temp = null;
        
        //Verifica se a lista está vazia
        if(getFim() != null && getInicio() != null) {
            temp = getFim();
            
            //Verifica se a célula funal e a inicial são as mesmas
            if(getFim() == getInicio()) {
                setFim(null);
                setInicio(null); 
            }
            else {
                getInicio().setAnterior(getFim().getAnterior());
                setFim(getFim().getAnterior());
                getFim().setProximo(getInicio());
            }
            //Define os endereços para esta célula temporária
            temp.setAnterior(null);
            temp.setProximo(null);
        }
        // Decrementa qtidade de nos
        setQtdNos(getQtdNos() - 1);
        return temp;
    }

    // -------------------------------------------------------------
    /**
     * Método inserirApos
     * Insere um novo nó no final da lista
     *
     * @param key Um parâmetro do tipo long que contém a 
     * chave de informações daquele nó
     * 
     * @param elem Um parâmetro do tipo objeto que contém as
     * ifnormações que irão compor aquele nó
     * 
     * @param linha Um parâmetro do tipo int que conterá a
     * posição de linha que aquele nó irá compor
     * 
     * @param coluna Um parâmetro do tipo int que conterá a
     * posição de coluna que aquele nó irá compor
     * 
     * @return O valor de retorno será a confirmação de que
     * aquele novo nó foi criado e inserido no fim
     */
    public boolean inserirApos(long key, Object elem,int linha,int coluna) {
        //Define um nó ponteiro para começar do início da lista
        No noAtual = getInicio(); 

        while((Long)noAtual.getId() != key) {
            if(noAtual == getFim()) {
                return false; 
            }
            noAtual = noAtual.getProximo(); 
        }
        
        //Cria um novo nó com seus respectivos atributos
        No novoNo = new No(elem, r.nextLong(),linha,coluna);

        if(noAtual==getFim()) {
            novoNo.setProximo(getInicio()); 
            setFim(novoNo); 
        }
        else {
            novoNo.setProximo(noAtual.getProximo());
            noAtual.getProximo().setAnterior(novoNo);
        }
        novoNo.setAnterior(noAtual);
        noAtual.setProximo(novoNo); 
        
        // Incrementa quantidade de nos
        setQtdNos(getQtdNos() + 1);
        return true; 
    }

    // -------------------------------------------------------------
    /**
     * Método remover
     * Remove um nó que está presente na lista
     *
     * @param chave Um parâmetro do tipo long que conterá a chave
     * de identificação para aquele nó a ser excluído
     * 
     * @return O valor de retorno será do tipo No e conterá
     * o nó que irá ser removido
     */
    public No remover(long chave) {
        No noAtual = null;
        if(getInicio() != null) {
            noAtual = getInicio();

            while((Long)noAtual.getId() != chave) {
                if(noAtual == getFim()) {
                    return null;                 
                }
                noAtual = noAtual.getProximo(); 
            }
            //Verifica se o nó de início é o mesmo do fim
            if(noAtual == getInicio()) {
                noAtual = removerInicio();
            } else if (noAtual == getFim()) {
                noAtual = removerFim();
            }
            else {
                noAtual.getAnterior().setProximo(noAtual.getProximo());
                noAtual.getProximo().setAnterior(noAtual.getAnterior());
                // Decrementa qtidade de nos
                setQtdNos(getQtdNos() - 1);
            }
            //Atribui as informações e características para aquele nó
            noAtual.setAnterior(null);
            noAtual.setProximo(null);

        }
        return noAtual;
    }

    // -------------------------------------------------------------
    /**
     * Método toString
     * Cria uma string que conterá todas as informações dos nós
     *
     * @return O valor de retorno será uma string com todos os
     * dados de todos os nós
     */
    public String toString() {
        String s = "[ ";
        No noAtual = getInicio();  //Inicia a partir do primeiro nó da lista
        
        
        //Verifica se o nó inicial não está vazio
        if(noAtual != null) {
            do {   
                s = s + noAtual.toString() + " ";  
                noAtual = noAtual.getProximo();   
            } while(noAtual != getInicio());
        }
        s = s + "]";
        return s;
    }

    // -------------------------------------------------------------
    /**
     * Método toStringDoFim semelhante comportamento ao toString anterior
     *
     * @return O valor de retorno desta String
     */
    public String toStringDoFim() {
        String s = "[ ";
        No noAtual = getFim();  // inicia no fim

        if(noAtual != null) {
            do {
                s = s + noAtual.toString() + " "; 
                noAtual = noAtual.getAnterior(); 
            }while(noAtual != getFim());
        }
        s = s + "]";
        return s;
    }
    
    /**
     * Método limparLista
     * Limpa a lista totalmente de seus conteúdos
     *
     */
    public void limparLista() {

        No temp = getInicio();

        while (temp != getFim()) {
            removerFim();
        }

        setInicio(null);
        setFim(null);

    }
}  
