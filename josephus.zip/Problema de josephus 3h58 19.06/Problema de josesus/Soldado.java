
/**
 * Esta classe contém todos os detalhes do soldado e 
 * suas propriedades básicas
 *
 * @author Lucas Kenji Hayashi, Giovana Akemi Maeda, Pedro Marques Prado, João Pedro Ribeiro
 * @version V2.0 - 17/06/2023
 */
public class Soldado
{
    //Status de vida do soldado
    boolean soldado;
    
    /**
     * Construtor da classe Soldado. Inicializa os objetos, métodos e funções
     * que serão utilizados
     */
    Soldado(){
          soldado = true;  
    }
    
    /**
     * Método getSoldado
     * Pega um soldado em específico que for desejado
     *
     * @return O valor de retorno será o status de vida deste soldado
     */
    public boolean getSoldado(){
        return this.soldado;
    }
    
    /**
     * Método setSoldado
     * Define um status de vida para este soldado
     *
     * @param soldado Um parâmetro do tipo booleano que contém o status
     * de vida deste soldado em específico
     */
    public void setSoldado(boolean soldado){
        this.soldado = soldado;
    }
}
